console.log('service-worker.js');

// window.self.addEventListener('install', (event) => {
// this.addEventListener('install', (event) => {
self.addEventListener('install', (event) => {
  console.log('Установлен');

  event.waitUntil(
    caches.open('my-cache')
      .then((cache) => {
        cache.addAll([
          '/',
          '/index.html',
          '/main.css',
          'http://localhost:8080/aaa.png',
          // 'aaa.png'

          // './node_modules/mini.css/dist/mini-default.min.css',
          // './css/mini-default.min.css',
          // './css/style.css',
          // '/component/movieNews/aaa.png',
        ]);
      }),

  );
  //   event.open('my-cache')
  //     .then((cache) => {
  //       cache.addAll([
  //         './',
  //         './index.html',
  //         './node_modules/mini.css/dist/mini-default.min.css',
  //         './style.css',
  //         './component/movieNews/aaa.png'
  //       ])

//     })
});

// window.self.addEventListener('activate', () => {
self.addEventListener('activate', () => {
  console.log('Активирован');
});

// window.self.addEventListener('fetch', () => {
self.addEventListener('fetch', (event) => {
  console.log('Происходит запрос на сервер');
  event.respondWith( // 1-авриант: всегда отвечать кешом.
    caches.match(event.request).then((response) => response || fetch(event.request).then((response) => caches.open('my-cache').then((cache) => {
      cache.put(event.request, response.clone());

      return response;
    }))),
  );
});
