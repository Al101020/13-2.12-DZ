console.log('service-worker.js');

// window.self.addEventListener('install', (event) => {
// this.addEventListener('install', (event) => {
self.addEventListener('install', (event) => {
  console.log('Установлен');

  event.waitUntil(
    caches.open('my-cache')
      .then((cache) => {
        cache.addAll([
          '/',
          '/index.html',
          '/main.css',
          'http://localhost:8080/aaa.png',
          // 'aaa.png'

          // './node_modules/mini.css/dist/mini-default.min.css',
          // './css/mini-default.min.css',
          // './css/style.css',
          // '/component/movieNews/aaa.png',
        ]);
      }),

  );
  //   event.open('my-cache')
  //     .then((cache) => {
  //       cache.addAll([
  //         './',
  //         './index.html',
  //         './node_modules/mini.css/dist/mini-default.min.css',
  //         './style.css',
  //         './component/movieNews/aaa.png'
  //       ])

//     })
});

// window.self.addEventListener('activate', () => {
self.addEventListener('activate', () => {
  console.log('Активирован');
});

// здесь вывели ответ fetch из self.addEventListener('fetch') в отдельную функцию
async function cachePriorityThenFetch(event) {
  console.log('-1-');
  // вставил чтобы страница не перегружалась
  event.preventDefault();

  // console.log(event);
  const cacheResponse = await caches.match(event.request);

  if (cacheResponse) {
    console.log(cacheResponse.body);
    return cacheResponse;
  }

  let response;

  console.log(response);

  try {
    response = await fetch(event.request);
  } catch (error) {
    return;
  }

  // try {

  // } catch (error) {
  //   return console.log('error:  try catch');
  // }

  const cache = await caches.open('my-cache');

  cache.put(event.request, response.clone());

  return response;
}

// window.self.addEventListener('fetch', () => {
self.addEventListener('fetch', (event) => {
  console.log('Происходит запрос на сервер');
  event.respondWith(cachePriorityThenFetch(event));
});
